<!--left side bar-->
<div class="col-md-2 mr-auto">Left Side Bar</div>