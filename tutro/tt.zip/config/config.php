<?php
define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/tutro/config.php');

echo BASEURL;